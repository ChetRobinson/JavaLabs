import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * A border of our world, to cover the left and right edges.
 * 
 * Shani Schneider
 * 12-10-2015
 */
public class Border extends Actor
{
    /**
     * Act - nothing to do. This object does not do anything.
     */
    public void act() 
    {
    }    
}
